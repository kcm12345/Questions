﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWord
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the number which needs to be converted.");
            var number = Console.ReadLine();
            var result = int.TryParse(number, out int enteredNumber);
            if (result)
            {
                var numberToConvert = enteredNumber < 0 ? Math.Abs(enteredNumber) : enteredNumber;
                NumConverter millionConverter = new MillionConverter();
                NumConverter thousandConverter = new ThousandConverter();
                NumConverter hundredConverter = new HundredConverter();
                hundredConverter.SetNext(thousandConverter);
                thousandConverter.SetNext(millionConverter);
                Console.WriteLine("Number to word convertor:\n");
                var convertedWord = enteredNumber < 0 ? "minus " + hundredConverter.ConvertNumber(numberToConvert) : hundredConverter.ConvertNumber(numberToConvert);
                Console.WriteLine(convertedWord);
            }
            else
            {
                Console.WriteLine("Input is not correct.");
            }
            Console.ReadLine();
        }
    }
}
