﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWord
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the number which needs to be converted.");
            var number = Console.ReadLine();
            int.TryParse(number, out int enteredNumber);
            NumConverter millionConverter = new MillionConverter();
            NumConverter thousandConverter = new ThousandConverter();
            NumConverter hundredConverter = new HundredConverter();
            hundredConverter.SetNext(thousandConverter);
            thousandConverter.SetNext(millionConverter);
            Console.WriteLine("Number to word convertor:\n");
            Console.WriteLine(hundredConverter.ConvertNumber(enteredNumber));
            Console.ReadLine();
        }
    }
}
