﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWord
{
    public abstract class NumConverter
    {
        protected NumConverter nextNumConverter;
        public void SetNext(NumConverter numConverter)
        {
            this.nextNumConverter = numConverter;
        }
        
        public abstract string ConvertNumber(int number);
    }
}
