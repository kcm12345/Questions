﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWord
{
    public class ThousandConverter: NumConverter
    {
        public override string ConvertNumber(int number)
        {
            var result = WordConverter.numToWords((number % 1000000)/1000);
            var convertedString = !string.IsNullOrEmpty(result) ? result + " thousand" : result;
            if (number >= 1000000 && this.nextNumConverter != null)
            {
                convertedString = this.nextNumConverter.ConvertNumber(number) + " " + convertedString;
            }

            return convertedString;
        }
    }
}
