﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWord
{
    public static class WordConverter
    {
        public static string numToWords(int n)
        {
            string str = string.Empty; 
            if (n > 100)
            {
                str += (words)(n / 100) + " hundred ";
                //var tenthDigit = n % 100;
                //if (tenthDigit > 0)
                //{
                //    str += " and " + (words)(tenthDigit);// / 10) + " " + (words)(tenthDigit % 10);
                //}
                var tenthDigit = n % 100;
                var num = tenthDigit % 10;
                if (num > 0 && tenthDigit > 10)
                {
                    str = str + " and ";
                    str += (words)(tenthDigit - num) + " " + (words)num;
                }
                else
                {
                    str = str + " and ";
                    str += (words)(tenthDigit);
                }
            }
            else //if (n > 19)
            {
                var num = n % 10;
                if (num > 0 && n > 10)
                {
                    str += (words)(n - num) + " " + (words)num;
                }
                else
                {
                    str += (words)(n);
                }

                //str = " and " + str;
            }
            //else
            //{
            //    str += (words)(n);
            //}

            return str;
        }
    }

    enum words
    {
        one = 1,
        two,
        three, 
        four, 
        five,
        six,
        seven,
        eight, 
        nine, 
        ten,
        eleven, 
        twelve, 
        thirteen,
        fourteen, 
        fifteen, 
        sixteen,
        seventeen, 
        eighteen, 
        nineteen,
        twenty = 20, 
        thirty = 30, 
        forty = 40, 
        fifty = 50,
        sixty = 60, 
        seventy = 70, 
        eighty = 80, 
        ninety = 90
    }
}
