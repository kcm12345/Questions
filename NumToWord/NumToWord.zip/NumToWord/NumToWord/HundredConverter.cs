﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWord
{
    public class HundredConverter:NumConverter
    {
        public override string ConvertNumber(int number)
        {
            var convertedString = WordConverter.numToWords(number%1000);
            //var convertedString = !string.IsNullOrEmpty(result) ? " Thousand" : result;
            if (number >= 1000 && this.nextNumConverter != null)
            {
                convertedString = this.nextNumConverter.ConvertNumber(number) + " " + convertedString;
            }

            return convertedString;
        }
    }
}
